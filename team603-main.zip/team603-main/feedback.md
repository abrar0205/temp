# Feedback for ss25.2.1/team603

**Team members:** if76evax-2, sa01juwe-2

**Total points:** 100

**General notes:**
1. Please reach out if you think there was a mistake with the grading.
2. If the feedback below provides suggestions how your submission could be improved, this is not a request that you actually update your submission (unless stated otherwise). However, you might use some of the suggestions in future assignments.

-----------------

Very good! All solutions are correct and you have a very detailed description of your solution.
Which makes grading easy for me: 100 points.
